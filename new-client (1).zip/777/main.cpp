#include "mainwindow.h"
#include<vector>
#include <QApplication>
#include<iostream>
#include<time.h>
#include<cstdlib>
#include<QLineEdit>
#include<QPushButton>
#include<QLabel>
#include<checker777.h>

int main(int argc, char *argv[])
{
    srand(time(0));
    QApplication a(argc, argv);
    MainWindow *w = new MainWindow;
    w->setGeometry(100, 100, 400, 400);
    std::vector<int> gen(10);
    std::vector<int> b(4);
    for (int i = 1; i <= 9; ++i) {
        gen[i-1] = i;
    }
    int i1 = rand()%9;
    b[0] = gen[i1];
    gen.erase(gen.begin()+i1);
    gen[8]=0;
    for (int i = 1; i < 4; ++i) {
        int i1 = rand()%(int)gen.size();
        b[i] = gen[i1];
        gen.erase(gen.begin()+i1);
    }
    QString t;
    for (int i : b) {
        std::cout << i;
        t += char(i+'0');
    }
    std::cout << std::endl;
    QLineEdit *edit = new QLineEdit(w);
    Checker777 *opa = new Checker777;
    opa->k = 0;
    opa->d1 = t;
    QPushButton *check = new QPushButton("Угадать", w);
    QLabel *label = new QLabel(w);
    QPushButton *strt = new QPushButton("Сдаться", w);
    label->setGeometry(140, 90, 500, 50);
    edit->setGeometry(10, 90, 110, 30);
    check->setGeometry(10, 140, 100, 30);
    strt->setGeometry(10, 180, 100, 30);
    QObject::connect(check, SIGNAL(clicked()), opa, SLOT(checkvalue777()));
    QObject::connect(edit, SIGNAL(textChanged(QString)), opa, SLOT(valuechanged777(QString)));
    QObject::connect(opa, SIGNAL(valuechecked777(QString)), label, SLOT(setText(QString)));
    QObject::connect(strt, SIGNAL(clicked()), opa, SLOT(NG()));
    QObject::connect(opa, &Checker777::WIN, strt, &QPushButton::setText);
    w->show();
    return a.exec();
}

