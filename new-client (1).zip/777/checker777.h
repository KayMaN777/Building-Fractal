#ifndef CHECKER777_H
#define CHECKER777_H
#include<QObject>
#include<vector>
class Checker777 : public QObject {
    Q_OBJECT;
public:
    explicit Checker777(QObject *parent=0);
    QString d1, d2;
    int k;
signals:
    void valuechecked777(QString);
    void WIN(QString);
public slots:
    void checkvalue777();
    void valuechanged777(QString);
    void NG();
};

#endif
