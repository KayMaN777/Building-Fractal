#include<checker777.h>
#include<vector>
#include<QString>
#include<iostream>
#include<set>
Checker777::Checker777(QObject *parent) : QObject(parent) {}

void Checker777::valuechanged777(QString t) {
    d2 = t;
}
int kol = 0;
bool fl=0;
QString lst;
QString get_word1(int kol) {
    if (kol == 0){
        return " быков\n";
    } else if (kol == 1) {
        return " бык\n";
    } else {
        return " быка\n";
    }
}
QString get_word2(int kol) {
    if (kol == 0) {
        return " коров\n";
    } else if (kol == 1) {
        return " корова\n";
    } else {
        return " коровы\n";
    }
}
void Checker777::NG() {
    if (!fl) {
        QString t = "Загаданное число: ";
        t += d1;
        emit valuechecked777(t);
        emit WIN("Новая игра");
        fl=1;
        lst="";
        kol=0;
        k = 1;
    } else {
        emit WIN("Сдаться");
        k = 0;
        emit valuechecked777("");
        std::vector<int> gen(10);
        std::vector<int> b(4);
        for (int i = 1; i <= 9; ++i) {
            gen[i-1] = i;
        }
        int i1 = rand()%9;
        b[0] = gen[i1];
        gen.erase(gen.begin()+i1);
        gen[8]=0;
        for (int i = 1; i < 4; ++i) {
            int i1 = rand()%(int)gen.size();
            b[i] = gen[i1];
            gen.erase(gen.begin()+i1);
        }
        QString t;
        for (int i : b) {
            std::cout << i;
            t += char(i+'0');
        }
        std::cout<<std::endl;
        d1 = t;
        //d2="";
        kol=0;
        lst="";
        fl=0;
    }
}

void Checker777::checkvalue777() {
    if (fl) {
        return;
    }
    std::set<QChar> used;
    //std::cout << d2[0];
    if (d2.size() != 4 || d2[0] == '0') {
        emit valuechecked777("некоректный ввод");
        return;
    }
    for (int i = 0; i < 4; ++i) {
        if (!('0' <= d2[i] && d2[i] <= '9') || used.find(d2[i]) != used.end()) {
            emit valuechecked777("некоректный ввод");
            return;
        }
        used.insert(d2[i]);
    }
    int kol1 = 0, kol2 = 0;
    for (int i = 0; i < 4; ++i) {
        if (d1[i] == d2[i]){
            kol1++;
        } else if (used.find(d1[i]) != used.end()) {
            kol2++;
        }
    }
    QString kk, t, p1, p2;
    if (d2 != lst) {
        lst = d2;
        ++kol;
    } else {
        return;
    }
    if (kol1 == 4) {
        t = "число угадано!\n";
        kk.setNum(kol);
        t += "Число попыток: ";
        t += kk;
        emit valuechecked777(t);
        k = 1;
        emit WIN("Новая игра");
        fl = 1;
        lst = "";
        kol = 0;
        return;
    }
    t.setNum(kol1);
    p1 = get_word1(kol1);
    p2 = get_word2(kol2);
    t += p1;
    kk.setNum(kol2);
    t += kk;
    t += p2;
    t += "Число попыток: ";
    kk.setNum(kol);
    t += kk;
    emit valuechecked777(t);
}

