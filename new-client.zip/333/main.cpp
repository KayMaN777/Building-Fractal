#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include "mywidget.h"
#include <QLayout>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QWidget *w = new QWidget;
    const int n = 300, m = 300;
    w->setMinimumSize(n, m);
    MyWidget *widget = new MyWidget(w);
    QPushButton *dec = new QPushButton(w);
    QPushButton *inc = new QPushButton(w);
    inc->setText("+1");
    dec->setText("-1");
    inc->setGeometry(0, 0, n / 4, m / 10);
    dec->setGeometry(n - n / 4, 0, m / 4, m / 10);
    widget->setGeometry(0, 0, n, m);
    QObject::connect(inc, SIGNAL(clicked()), widget, SLOT(incr()));
    QObject::connect(dec, SIGNAL(clicked()), widget, SLOT(decr()));
    QVBoxLayout *opa = new QVBoxLayout();
    opa->addWidget(inc, 1);
    opa->addWidget(widget, 0);
    opa->addWidget(dec, 2);
    w->setLayout(opa);
    w->show();
    return a.exec();
}
