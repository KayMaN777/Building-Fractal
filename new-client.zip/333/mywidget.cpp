#include "mywidget.h"
#include <QPainter>
#include <cmath>
const int n_max = 7;
typedef long double ld;
MyWidget::MyWidget(QWidget *parent) : QWidget(parent)
{
}

void draw(int n, ld x1, ld y1, ld x2, ld y2, QPainter &painter) {
    if (!n) {
        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    } else {
        ld dl = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
        ld dx = (x2 - x1) / 3;
        ld dy = (y2 - y1) / 3;
        draw(n-1, x1, y1, x1 + dx, y1+dy, painter);
        draw(n-1, x2 - dx, y2 - dy, x2, y2, painter);
        dl/=3;
        ld angle = atan2((y2 - y1 - 2 * dy), (x2 - x1 - 2*dx)) - M_PI / 3;
        ld x_opa = x1 + dx + cos(angle) * dl;
        ld y_opa = y1 + dy + sin(angle) * dl;
        draw(n-1, x1 + dx, y1 + dy, x_opa, y_opa, painter);
        draw(n-1, x_opa, y_opa, x2 - dx, y2 - dy, painter);
    }
}

void MyWidget::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
    ld w, h;
    if (width() * sqrt(3) / 6 < height()) {
        h = width() * sqrt(3) / 6;
        w = width();
    } else {
        h = height();
        w = height() * 2 * sqrt(3);
    }
    draw(n, width()/2-w/2, height()/2+h/2, width()/2+w/2, height()/2+h/2, painter);
}

void MyWidget::incr()
{
    n = qMin(n_max, n+1);
    repaint();
}
void MyWidget::decr() {
    n = qMax(0, n-1);
    repaint();
}
